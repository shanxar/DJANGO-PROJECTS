from django.contrib import admin
from .models import  Employee_model

# Register your models here.
admin.site.register(Employee_model)
