from django.db import models

# Create your models here.
class Employee_model(models.Model):
    emp_name=models.CharField(max_length=150)
    emp_id=models.IntegerField()
    experience=models.IntegerField()
