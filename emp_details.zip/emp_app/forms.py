from django import forms
from django.forms import ModelForm 
from . import models

class Emp_form(forms.ModelForm):
    
    class Meta: 
        model =  models.Employee_model
        fields = '__all__'
        