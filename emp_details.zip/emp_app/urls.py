from django.urls import path,include
from . import views

urlpatterns = [
    path('',views.emp_details,name="emp_home"),
    path('update/<id>',views.emp_update,name="update"),
    path('delete/<id>',views.emp_delete,name="delete")
    
]