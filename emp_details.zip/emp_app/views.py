from django.shortcuts import render,redirect
from django.http import HttpResponse
from .models import Employee_model
from .forms import Emp_form

# Create your views here.


def emp_details(request):
    emp_object=Employee_model.objects.all()
    emp_form=Emp_form()
    
    if request.method =='POST':
         emp_form=Emp_form(request.POST)
         emp_form.save()
    
    
    context={'emp_object':emp_object , 'emp_form': emp_form}
    return render(request,"emp_temp\emp_app.html",context)

def emp_update(request,id):
    emp_object=Employee_model.objects.get(pk=id)
    emp_form=Emp_form(instance=emp_object)
    
    if request.method =='POST':
        emp_form=Emp_form(request.POST,instance=emp_object)
        emp_form.save()
        return redirect("emp_home")
    
    context={'emp_form': emp_form}
    return render(request,"emp_temp\emp_update.html",context)

def emp_delete(request,id):
    emp_object=Employee_model.objects.get(pk=id)
    emp_form=Emp_form(instance=emp_object)
    
    if request.method =='POST':
        #emp_form=Emp_form(instance=emp_object)
        return redirect("emp_home")
    
    context={"emp_object":emp_object,"emp_form":emp_form}
    return render(request,"emp_temp\emp_delete.html",context)
   
   
    
   
   
